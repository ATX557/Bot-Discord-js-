/**
 * @namespace: addons/pet/register.js
 * @type: Module
 * @copyright © 2025 kenndeclouv
 * @assistant chaa & graa
 * @version 0.10.1-beta
 */

module.exports = {
	async initialize(_bot) {
		return [' └─ 🐾 Pet models loaded & associated automatically.'];
	},
};
