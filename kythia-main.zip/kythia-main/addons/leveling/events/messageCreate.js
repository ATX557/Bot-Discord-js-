/**
 * @namespace: addons/leveling/events/messageCreate.js
 * @type: Event Handler
 * @copyright © 2025 kenndeclouv
 * @assistant chaa & graa
 * @version 0.10.1-beta
 */

const { addXp } = require('../helpers');
const cooldown = new Map();

/**
 * Auto-claim streak on any message in a guild (except bots).
 * @param {import('../../src/Bot')} bot - Instance of main Bot class.
 * @param {import('discord.js').Message} message - The message object.
 */
module.exports = async (bot, message) => {
	const { ServerSetting } = bot.client.container.models;
	if (message.author.bot || !message.guild) return;
	const guildId = message.guild.id;
	const userId = message.author.id;
	const { helpers } = bot.client.container;
	const { getChannelSafe } = helpers.discord;

	const setting = await ServerSetting.getCache({ guildId });
	if (!setting || !setting.levelingOn) return;

	const xpPerMessage =
		typeof setting.levelingXp === 'number' ? setting.levelingXp : 15;
	const cooldownTime =
		typeof setting.levelingCooldown === 'number'
			? setting.levelingCooldown
			: 60000;
	const key = `${guildId}-${userId}`;
	const now = Date.now();

	if (now - (cooldown.get(key) || 0) >= cooldownTime) {
		const channel =
			(await getChannelSafe(message.guild, setting.levelingChannelId)) ||
			message.channel;
		await addXp(guildId, userId, xpPerMessage, message, channel);
		cooldown.set(key, now);
	}
};
