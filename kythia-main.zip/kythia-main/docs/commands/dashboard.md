## 🌐 Dashboard Access

To manage your settings, view your stats, or customize your experience, please use the Kythia Dashboard:

👉 **Visit:** [https://kythia.my.id](https://kythia.my.id)

> **Note:** You must log in to access the dashboard and its features.
>
> Simply log in with your Discord account for instant access!

Once logged in, you'll be able to access various dashboard functions depending on your permissions and role.
